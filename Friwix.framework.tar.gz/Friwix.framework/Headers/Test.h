//
//  Test.h
//  FriwixOBJ
//
//  Created by TheMadBox on 15/06/16.
//  Copyright © 2016 TheMadBox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Test : NSObject

- (void) prova;

@end
