//
//  Friwix.h
//  Friwix
//
//  Created by TheMadBox on 16/06/16.
//  Copyright © 2016 TheMadBox. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Friwix.
FOUNDATION_EXPORT double FriwixVersionNumber;

//! Project version string for Friwix.
FOUNDATION_EXPORT const unsigned char FriwixVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Friwix/PublicHeader.h>


#import "Test.h"